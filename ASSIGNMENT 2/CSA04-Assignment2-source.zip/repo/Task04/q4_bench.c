#define _POSIX_C_SOURCE 200809L
#define _DEFAULT_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <time.h>
#include <semaphore.h>
#include <sys/mman.h>
#include <sys/wait.h>
#define CHUNK 65536
#define SLOTS 16
static double now(void){struct timespec t;clock_gettime(CLOCK_MONOTONIC,&t);return t.tv_sec+t.tv_nsec/1e9;}
static double pipe_xfer(size_t total)
{
    int fd[2]; if (pipe(fd)) { perror("pipe"); exit(1); }
    double t0 = now();
    pid_t pid = fork();
    if (pid == 0) { close(fd[1]); char *b = malloc(CHUNK); size_t got = 0; ssize_t r; unsigned long s = 0;
        while ((r = read(fd[0], b, CHUNK)) > 0) { got += r; s += b[0]; }
        _exit(got == total ? 0 : 1); }
    close(fd[0]); char *b = malloc(CHUNK); memset(b, 7, CHUNK);
    for (size_t sent = 0; sent < total; sent += CHUNK) if (write(fd[1], b, CHUNK) < 0) perror("write");
    close(fd[1]); int st; waitpid(pid, &st, 0);
    double t = now() - t0; free(b);
    return WEXITSTATUS(st) ? -1 : t;
}
struct shm { sem_t empty, full; int len[SLOTS]; char data[SLOTS][CHUNK]; };
static double shm_xfer(size_t total)
{
    struct shm *s = mmap(NULL, sizeof *s, PROT_READ|PROT_WRITE, MAP_SHARED|MAP_ANONYMOUS, -1, 0);
    sem_init(&s->empty, 1, SLOTS); sem_init(&s->full, 1, 0);
    double t0 = now();
    pid_t pid = fork();
    if (pid == 0) { size_t got = 0; int out = 0; unsigned long sum = 0;
        while (got < total) { sem_wait(&s->full); sum += s->data[out][0]; got += s->len[out]; out = (out + 1) % SLOTS; sem_post(&s->empty); }
        _exit(got == total ? 0 : 1); }
    char *b = malloc(CHUNK); memset(b, 7, CHUNK); int in = 0;
    for (size_t sent = 0; sent < total; sent += CHUNK) {
        sem_wait(&s->empty); memcpy(s->data[in], b, CHUNK); s->len[in] = CHUNK; in = (in + 1) % SLOTS; sem_post(&s->full); }
    int st; waitpid(pid, &st, 0);
    double t = now() - t0; free(b); munmap(s, sizeof *s);
    return WEXITSTATUS(st) ? -1 : t;
}
int main(void)
{
    size_t mb[] = {1, 10, 100};
    printf("MB,pipe_s,shm_sem_s,pipe_MBps,shm_MBps\n");
    for (int i = 0; i < 3; i++) {
        size_t n = mb[i] * 1024 * 1024; double bp = 1e9, bs = 1e9;
        for (int k = 0; k < 5; k++) { double a = pipe_xfer(n), c = shm_xfer(n); if (a < bp) bp = a; if (c < bs) bs = c; }
        printf("%zu,%.4f,%.4f,%.0f,%.0f\n", mb[i], bp, bs, mb[i] / bp, mb[i] / bs);
    }
    return 0;
}
