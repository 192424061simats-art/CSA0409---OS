#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <pthread.h>
#include <sched.h>
#include <stdatomic.h>
#define T 4
#define ITER 1000000
static long unsafe_c = 0, mutex_c = 0; static atomic_long atom_c;
static pthread_mutex_t m = PTHREAD_MUTEX_INITIALIZER;
static void *work(void *a){(void)a;for(int i=0;i<ITER;i++){
  long tmp = unsafe_c; if ((i & 1023) == 0) sched_yield(); unsafe_c = tmp + 1; /* read-modify-write, window widened */
  pthread_mutex_lock(&m);mutex_c++;pthread_mutex_unlock(&m);
  atomic_fetch_add(&atom_c,1);}return NULL;}
int main(void){pthread_t t[T];
 for(int i=0;i<T;i++)pthread_create(&t[i],NULL,work,NULL);
 for(int i=0;i<T;i++)pthread_join(t[i],NULL);
 printf("expected   : %d\nunprotected: %ld\nmutex      : %ld\natomic     : %ld\n",T*ITER,unsafe_c,mutex_c,(long)atom_c);return 0;}
