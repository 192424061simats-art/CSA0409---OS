#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>
#include <sched.h>
#include <time.h>
#include <stdatomic.h>
#define CAMERAS 64
static int io_us = 5000;          /* simulated camera/network read per frame (I/O wait) */
static long cpu_iters = 1500000;  /* simulated plate recognition (CPU work)             */
static long plates_unsafe = 0;    /* shared counter, no protection  */
static long plates_mutex = 0;     /* protected with mutex           */
static atomic_long plates_atomic; /* protected with C11 atomics     */
static pthread_mutex_t m = PTHREAD_MUTEX_INITIALIZER;
static double now(void){struct timespec t;clock_gettime(CLOCK_MONOTONIC,&t);return t.tv_sec+t.tv_nsec/1e9;}
static volatile unsigned long sink;
static void process_camera(int cam)
{
    nanosleep(&(struct timespec){0, (long)io_us*1000L}, NULL);                                  /* read frame (blocks -> waiting state) */
    unsigned long x = cam + 1;
    for (long i = 0; i < cpu_iters; i++) x = x * 6364136223846793005UL + 1442695040888963407UL;
    sink = x;                                       /* recognise plate (CPU)               */
    plates_unsafe++;                                /* data race on purpose                */
    pthread_mutex_lock(&m); plates_mutex++; pthread_mutex_unlock(&m);
    atomic_fetch_add(&plates_atomic, 1);
}
static int next_cam = 0;                            /* work queue index */
static void *worker(void *arg)
{
    (void)arg;
    for (;;) {
        pthread_mutex_lock(&m);
        int c = next_cam < CAMERAS ? next_cam++ : -1;
        pthread_mutex_unlock(&m);
        if (c < 0) break;
        process_camera(c);
    }
    return NULL;
}
static double run(int nthreads)
{
    next_cam = 0;
    double t0 = now();
    if (nthreads == 0) { for (int c = 0; c < CAMERAS; c++) process_camera(c); return now() - t0; }
    pthread_t th[CAMERAS];
    for (int i = 0; i < nthreads; i++) pthread_create(&th[i], NULL, worker, NULL);
    for (int i = 0; i < nthreads; i++) pthread_join(th[i], NULL);
    return now() - t0;
}
int main(int argc, char **argv)
{
    if (argc > 1) io_us = atoi(argv[1]);
    if (argc > 2) cpu_iters = atol(argv[2]);
    int cfg[] = {0, 4, 8, 16, 64};
    printf("io_us=%d cpu_iters=%ld cores=%ld\n", io_us, cpu_iters, sysconf(_SC_NPROCESSORS_ONLN));
    double base = 0;
    printf("threads,time_s,speedup\n");
    for (int k = 0; k < 5; k++) {
        double best = 1e9;
        for (int rep = 0; rep < 3; rep++) { double t = run(cfg[k]); if (t < best) best = t; }
        if (k == 0) base = best;
        printf("%s%d,%.4f,%.2f\n", cfg[k]==0?"serial-":"", cfg[k], best, base / best);
    }
    return 0;
}
