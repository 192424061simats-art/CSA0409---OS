# CSA04-<RegisterNumber>-Assignment2

- Name: <your name>
- Register number: <RegisterNumber>
- Compiler: gcc 13.3.0 (Ubuntu 13.3.0-6ubuntu2~24.04.1)
- Linux: Ubuntu 24.04.5 LTS
- Compile command: `gcc -std=c11 -Wall -Wextra -pthread file.c -o name` (add `-O2` for the benchmarks)
- Note: results were produced on a machine with 1 logical CPU. Re-run on your own machine and replace the outputs/screenshots with yours.

| Folder | Program | Run |
|---|---|---|
| Task01 | q1_fork.c, q1_bench.c | `./q1_fork`, `./q1_bench` |
| Task02 | q2_rr.c (`-DQUANTUM=3/1/5/20`), sched.py | `./rr_q3`, `python3 sched.py` |
| Task03 | q3_threads.c, q3_race.c | `./q3_threads`, `./q3_threads 0 3000000`, `./q3_race` |
| Task04 | q4_pipe.c (`-DNO_CLOSE` for the hang), q4_bench.c | `./q4_pipe`, `timeout 3 ./q4_pipe_noclose`, `./q4_bench` |
| Task05 | q5_buffer.c (`-DPROD=4 -DCONS=4`, `-DNOMUTEX`), q5_locks.c, q5_atomic.c | see report section 6 |
| Task06 | q6_banker.c, q6_time.c | `./q6_banker`, `./q6_time` |
| charts | mk12.py, mkstate.py, mk36.py | `python3 mk12.py` (needs matplotlib) |

Commit one task at a time (at least six commits).
