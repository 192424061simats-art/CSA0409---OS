#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
/* Safety algorithm on a worst-case chain: only one process can finish per pass => O(m n^2) */
static double now(void){struct timespec t;clock_gettime(CLOCK_MONOTONIC,&t);return t.tv_sec+t.tv_nsec/1e9;}
static int safe(int n, int m, int *need, int *alloc, int *avail)
{
    int *work = malloc(m * sizeof(int)), *fin = calloc(n, sizeof(int)), count = 0;
    memcpy(work, avail, m * sizeof(int));
    while (count < n) {
        int found = 0;
        for (int p = 0; p < n; p++) {
            if (fin[p]) continue;
            int ok = 1;
            for (int r = 0; r < m; r++) if (need[p*m+r] > work[r]) { ok = 0; break; }
            if (ok) { for (int r = 0; r < m; r++) work[r] += alloc[p*m+r]; fin[p] = 1; count++; found = 1; }
        }
        if (!found) { free(work); free(fin); return 0; }
    }
    free(work); free(fin); return 1;
}
static double bench(int n, int m, int reps)
{
    int *need = malloc(n*m*sizeof(int)), *alloc = malloc(n*m*sizeof(int)), *avail = malloc(m*sizeof(int));
    for (int r = 0; r < m; r++) avail[r] = 1;
    for (int p = 0; p < n; p++) for (int r = 0; r < m; r++) { alloc[p*m+r] = 1; need[p*m+r] = n - p; } /* last process needs 1, then 2, ... */
    double t0 = now(); int ok = 1;
    for (int k = 0; k < reps; k++) ok &= safe(n, m, need, alloc, avail);
    double t = (now() - t0) / reps;
    if (!ok) fprintf(stderr, "state unexpectedly unsafe\n");
    free(need); free(alloc); free(avail); return t;
}
int main(void)
{
    printf("n,m,time_ms\n");
    int ns[] = {10, 100, 1000};
    for (int i = 0; i < 3; i++) printf("%d,5,%.5f\n", ns[i], bench(ns[i], 5, ns[i] == 1000 ? 5 : ns[i] == 100 ? 500 : 50000) * 1000);
    int ms[] = {5, 10, 20, 40};
    for (int i = 0; i < 4; i++) printf("200,%d,%.5f\n", ms[i], bench(200, ms[i], 50) * 1000);
    return 0;
}
