#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>
#include <time.h>
#include <sys/wait.h>
static double now(void){struct timespec t;clock_gettime(CLOCK_MONOTONIC,&t);return t.tv_sec+t.tv_nsec/1e9;}
static void *nop(void *a){(void)a;return NULL;}
/* ping-pong over two pipes: each round trip = 2 context switches */
static int p2c[2], c2p[2];
static void *echo_thread(void *a){char b;(void)a;while(read(p2c[0],&b,1)==1) if(write(c2p[1],&b,1)<0) break;return NULL;}
int main(void)
{
    int sizes[] = {100, 500, 1000, 2000};
    printf("N,fork_ms,thread_ms\n");
    for (int s = 0; s < 4; s++) {
        int n = sizes[s];
        double t0 = now();
        for (int i = 0; i < n; i++) { pid_t p = fork(); if (p == 0) _exit(0); waitpid(p, NULL, 0); }
        double tf = (now() - t0) * 1000;
        t0 = now();
        for (int i = 0; i < n; i++) { pthread_t t; pthread_create(&t, NULL, nop, NULL); pthread_join(t, NULL); }
        double tt = (now() - t0) * 1000;
        printf("%d,%.2f,%.2f\n", n, tf, tt);
    }
    int R = 100000; char b = 'x';
    if (pipe(p2c) || pipe(c2p)) return 1;
    pid_t pid = fork();
    if (pid == 0) { close(p2c[1]); while (read(p2c[0], &b, 1) == 1) if (write(c2p[1], &b, 1) < 0) break; _exit(0); }
    double t0 = now();
    for (int i = 0; i < R; i++) { if (write(p2c[1], &b, 1) < 0) return 1; if (read(c2p[0], &b, 1) < 0) return 1; }
    double tp = now() - t0;
    close(p2c[1]); waitpid(pid, NULL, 0);
    printf("process_switch_us,%.3f\n", tp / (2.0 * R) * 1e6);
    if (pipe(p2c) || pipe(c2p)) return 1;
    pthread_t th; pthread_create(&th, NULL, echo_thread, NULL);
    t0 = now();
    for (int i = 0; i < R; i++) { if (write(p2c[1], &b, 1) < 0) return 1; if (read(c2p[0], &b, 1) < 0) return 1; }
    double tth = now() - t0;
    close(p2c[1]); pthread_join(th, NULL);
    printf("thread_switch_us,%.3f\n", tth / (2.0 * R) * 1e6);
    return 0;
}
