#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
/* Exam server model: parent = server, children = one process per student session */
int main(void)
{
    const int N = 5;
    pid_t kids[5];
    printf("server pid=%d\n", getpid()); fflush(stdout);
    for (int i = 0; i < N; i++) {
        pid_t pid = fork();
        if (pid < 0) { perror("fork"); exit(1); }
        if (pid == 0) {                       /* child = student session */
            printf("session %d: pid=%d ppid=%d\n", i + 1, getpid(), getppid());
            fflush(stdout);
            sleep(3);                         /* waiting state (like blocked on I/O) */
            _exit(i);
        }
        kids[i] = pid;
    }
    sleep(1);
    char cmd[128];
    printf("\n--- ps output (children of server) ---\n"); fflush(stdout);
    snprintf(cmd, sizeof cmd, "ps -o pid,ppid,stat,vsz,rss,comm --ppid %d", getpid());
    system(cmd);
    printf("\n--- /proc/%d/status (first session) ---\n", kids[0]); fflush(stdout);
    snprintf(cmd, sizeof cmd, "grep -E 'Name|State|Pid|PPid|VmSize|VmRSS|voluntary' /proc/%d/status", kids[0]);
    system(cmd);
    for (int i = 0; i < N; i++) {
        int st; waitpid(kids[i], &st, 0);
        printf("session pid %d terminated, exit code %d\n", kids[i], WEXITSTATUS(st));
    }
    return 0;
}
