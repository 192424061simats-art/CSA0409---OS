import json
names=["P1","P2","P3","P4"]; arr=[0,1,2,3]; bur=[8,4,9,5]; pri=[2,4,1,3]
def stats(fin,first):
    tat=[fin[i]-arr[i] for i in range(4)]; wt=[tat[i]-bur[i] for i in range(4)]; rt=[first[i]-arr[i] for i in range(4)]
    return tat,wt,rt
def nonpre(key):
    t=0;done=set();fin=[0]*4;first=[0]*4;g=[]
    while len(done)<4:
        rdy=[i for i in range(4) if i not in done and arr[i]<=t]
        if not rdy: t=min(arr[i] for i in range(4) if i not in done); continue
        p=min(rdy,key=lambda i:(key(i),arr[i]))
        first[p]=t; g.append((names[p],t,t+bur[p])); t+=bur[p]; fin[p]=t; done.add(p)
    return g,stats(fin,first)
def srtf():
    left=bur[:];t=0;fin=[0]*4;first=[None]*4;g=[]
    while any(left):
        rdy=[i for i in range(4) if left[i]>0 and arr[i]<=t]
        p=min(rdy,key=lambda i:(left[i],arr[i]))
        if first[p] is None:first[p]=t
        if g and g[-1][0]==names[p] and g[-1][2]==t: g[-1]=(names[p],g[-1][1],t+1)
        else: g.append((names[p],t,t+1))
        left[p]-=1;t+=1
        if left[p]==0: fin[p]=t
    return g,stats(fin,first)
def rr(q):
    left=bur[:];t=0;queue=[0];added={0};fin=[0]*4;first=[None]*4;g=[]
    while queue:
        p=queue.pop(0)
        if first[p] is None:first[p]=t
        run=min(q,left[p]);g.append((names[p],t,t+run));t+=run;left[p]-=run
        for i in range(4):
            if i not in added and arr[i]<=t: queue.append(i);added.add(i)
        if left[p]>0:queue.append(p)
        else:fin[p]=t
    return g,stats(fin,first)
def mlfq(quanta=(2,4,8)):
    # 3 queues, new jobs enter Q0, demoted when quantum used up; higher queue always first
    left=bur[:];t=0;lvl=[0]*4;qs=[[],[],[]];added=set();fin=[0]*4;first=[None]*4;g=[]
    def admit():
        for i in range(4):
            if i not in added and arr[i]<=t: qs[0].append(i);added.add(i)
    admit()
    while any(left):
        admit()
        k=next((j for j in range(3) if qs[j]),None)
        if k is None: t+=1;continue
        p=qs[k].pop(0)
        if first[p] is None:first[p]=t
        run=min(quanta[k],left[p]);g.append((names[p],t,t+run));t+=run;left[p]-=run
        admit()
        if left[p]==0:fin[p]=t
        else:
            lvl[p]=min(k+1,2);qs[lvl[p]].append(p)
    return g,stats(fin,first)
res={}
res["FCFS"]=nonpre(lambda i:arr[i])
res["SJF"]=nonpre(lambda i:bur[i])
res["SRTF"]=srtf()
res["Priority"]=nonpre(lambda i:pri[i])
res["RR q=3"]=rr(3)
res["MLFQ 2/4/8"]=mlfq()
out={}
for k,(g,(tat,wt,rt)) in res.items():
    print(k,"Gantt:"," ".join(f"{n}({a}-{b})" for n,a,b in g))
    print("  TAT",tat,"WT",wt,"RT",rt,"avgTAT %.2f avgWT %.2f avgRT %.2f"%(sum(tat)/4,sum(wt)/4,sum(rt)/4))
    out[k]=dict(gantt=g,tat=tat,wt=wt,rt=rt,atat=sum(tat)/4,awt=sum(wt)/4,art=sum(rt)/4)
qs={}
for q in (1,3,5,20):
    g,(tat,wt,rt)=rr(q);qs[q]=dict(awt=sum(wt)/4,atat=sum(tat)/4,art=sum(rt)/4,cs=len(g))
    print("RR",q,qs[q])
json.dump(dict(res=out,quanta=qs),open("sched.json","w"))
