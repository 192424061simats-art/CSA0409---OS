#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <time.h>
#define TRAINS 8
#define COACHES 4
#define SEATS 1000         /* seats per coach (capacity 32,000 > 24,000 requests) */
#define THREADS 16
#define BOOK_PER_THREAD 1500
#define DB_NS 50000        /* simulated 50 us database/payment write inside the critical section */
static int taken[TRAINS][COACHES];
static pthread_mutex_t gl = PTHREAD_MUTEX_INITIALIZER, tl[TRAINS], cl[TRAINS][COACHES];
static int mode;           /* 0 global, 1 per train, 2 per coach */
static double now(void){struct timespec t;clock_gettime(CLOCK_MONOTONIC,&t);return t.tv_sec+t.tv_nsec/1e9;}
static void *agent(void *a)
{
    unsigned s = (unsigned)(long)a * 2654435761u + 1;
    for (int i = 0; i < BOOK_PER_THREAD; i++) {
        s = s * 1103515245u + 12345u; int t = (s >> 8) % TRAINS;
        s = s * 1103515245u + 12345u; int c = (s >> 8) % COACHES;
        pthread_mutex_t *m = mode == 0 ? &gl : mode == 1 ? &tl[t] : &cl[t][c];
        pthread_mutex_lock(m);
        if (taken[t][c] < SEATS) {
            int seat = taken[t][c];
            nanosleep(&(struct timespec){0, DB_NS}, NULL);   /* write booking to storage */
            taken[t][c] = seat + 1;                          /* commit seat */
        }
        pthread_mutex_unlock(m);
    }
    return NULL;
}
int main(void)
{
    for (int t = 0; t < TRAINS; t++) { pthread_mutex_init(&tl[t], NULL); for (int c = 0; c < COACHES; c++) pthread_mutex_init(&cl[t][c], NULL); }
    const char *nm[] = {"global lock", "per-train lock", "per-coach lock"};
    printf("lock,time_s,bookings_per_s,seats_sold,expected\n");
    for (mode = 0; mode < 3; mode++) {
        for (int t = 0; t < TRAINS; t++) for (int c = 0; c < COACHES; c++) taken[t][c] = 0;
        pthread_t th[THREADS]; double t0 = now();
        for (long i = 0; i < THREADS; i++) pthread_create(&th[i], NULL, agent, (void *)i);
        for (int i = 0; i < THREADS; i++) pthread_join(th[i], NULL);
        double el = now() - t0; long sold = 0;
        for (int t = 0; t < TRAINS; t++) for (int c = 0; c < COACHES; c++) sold += taken[t][c];
        printf("%s,%.3f,%.0f,%ld,%d\n", nm[mode], el, THREADS * BOOK_PER_THREAD / el, sold, THREADS * BOOK_PER_THREAD);
    }
    return 0;
}
