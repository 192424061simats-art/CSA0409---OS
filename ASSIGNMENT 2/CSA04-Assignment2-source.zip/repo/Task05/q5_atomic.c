#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <pthread.h>
#include <stdatomic.h>
#include <sched.h>
#include <time.h>
#define N 1000000
static atomic_long ac; static long lc_m, lc_s; static pthread_mutex_t m = PTHREAD_MUTEX_INITIALIZER;
static atomic_flag sp = ATOMIC_FLAG_INIT; static int mode;
static double now(void){struct timespec t;clock_gettime(CLOCK_MONOTONIC,&t);return t.tv_sec+t.tv_nsec/1e9;}
static double cpu(void){struct timespec t;clock_gettime(CLOCK_PROCESS_CPUTIME_ID,&t);return t.tv_sec+t.tv_nsec/1e9;}
static void *w(void *a){(void)a;for(int i=0;i<N;i++){
  if(mode==0) atomic_fetch_add(&ac,1);
  else if(mode==1){pthread_mutex_lock(&m);lc_m++;pthread_mutex_unlock(&m);}
  else {while(atomic_flag_test_and_set_explicit(&sp,memory_order_acquire)){} lc_s++; atomic_flag_clear_explicit(&sp,memory_order_release);} }
  return NULL;}
int main(void){const char*nm[]={"atomic","mutex","spinlock"};int ts[]={1,4,16};
 printf("method,threads,ns_per_update,cpu_s,wall_s,final_ok\n");
 for(mode=0;mode<3;mode++)for(int k=0;k<3;k++){int T=ts[k];ac=0;lc_m=0;lc_s=0;pthread_t th[16];
  double t0=now(),c0=cpu();for(int i=0;i<T;i++)pthread_create(&th[i],NULL,w,NULL);for(int i=0;i<T;i++)pthread_join(th[i],NULL);
  double wl=now()-t0,cp=cpu()-c0;long v=mode==0?ac:mode==1?lc_m:lc_s;
  printf("%s,%d,%.1f,%.3f,%.3f,%s\n",nm[mode],T,wl*1e9/((double)N*T),cp,wl,v==(long)N*T?"yes":"NO");}
 return 0;}
