#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <pthread.h>
#include <semaphore.h>
#include <sched.h>
#define SIZE 5
#ifndef ITEMS
#define ITEMS 20
#endif
#ifndef PROD
#define PROD 1
#endif
#ifndef CONS
#define CONS 1
#endif
int buffer[SIZE], in = 0, out = 0;
sem_t empty, full;
pthread_mutex_t lock = PTHREAD_MUTEX_INITIALIZER;
long consumed_sum = 0; long consumed_count = 0;
#ifdef NOMUTEX
#define LOCK()
#define UNLOCK()
#else
#define LOCK() pthread_mutex_lock(&lock)
#define UNLOCK() pthread_mutex_unlock(&lock)
#endif
void *producer(void *arg)
{
(void)arg;
for (int item = 1; item <= ITEMS; item++) {
sem_wait(&empty);
LOCK();
int slot = in; sched_yield();            /* widen race window (no effect when locked) */
buffer[slot] = item;
in = (slot + 1) % SIZE;
UNLOCK();
sem_post(&full);
}
return NULL;
}
pthread_mutex_t sumlock = PTHREAD_MUTEX_INITIALIZER;
void *consumer(void *arg)
{
(void)arg;
for (int k = 0; k < ITEMS * PROD / CONS; k++) {
sem_wait(&full);
LOCK();
int slot = out; sched_yield();
int item = buffer[slot];
out = (slot + 1) % SIZE;
UNLOCK();
sem_post(&empty);
pthread_mutex_lock(&sumlock); consumed_sum += item; consumed_count++; pthread_mutex_unlock(&sumlock);
}
return NULL;
}
int main(void)
{
sem_init(&empty, 0, SIZE);
sem_init(&full, 0, 0);
pthread_t p[PROD], c[CONS];
for (int i = 0; i < PROD; i++) pthread_create(&p[i], NULL, producer, NULL);
for (int i = 0; i < CONS; i++) pthread_create(&c[i], NULL, consumer, NULL);
for (int i = 0; i < PROD; i++) pthread_join(p[i], NULL);
for (int i = 0; i < CONS; i++) pthread_join(c[i], NULL);
printf("items consumed: %ld, sum = %ld (expected %d)\n", consumed_count, consumed_sum,
PROD * ITEMS * (ITEMS + 1) / 2);
sem_destroy(&empty);
sem_destroy(&full);
return 0;
}
