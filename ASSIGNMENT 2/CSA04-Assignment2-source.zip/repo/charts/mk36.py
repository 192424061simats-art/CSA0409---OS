import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch, Circle
plt.rcParams.update({"font.family":"serif","font.serif":["Liberation Serif"],"font.size":9})
B,O,G="#1f4e79","#c55a11","#548235"
def rd(f):
    return [l.strip().split(",") for l in open(f) if l.strip() and not l.startswith(("io_","threads","MB","lock","method","n,"))]
# Q3 speedups
io=[r for r in rd("../Task03/output_threads_io.txt")]; cp=[r for r in rd("../Task03/output_threads_cpu.txt")]
lab=["1 (serial)","4","8","16","64"]
fig,ax=plt.subplots(figsize=(4.80,2.78));x=range(5);w=.38
ax.bar([i-w/2 for i in x],[float(r[2]) for r in io],w,label="I/O + CPU workload",color=B)
ax.bar([i+w/2 for i in x],[float(r[2]) for r in cp],w,label="CPU-only workload",color=O)
ax.axhline(1,color="gray",lw=.8,ls=":");ax.set_xticks(list(x));ax.set_xticklabels(lab);ax.set_xlabel("Threads (pool size)");ax.set_ylabel("Speed-up vs serial");ax.set_title("Q3: Speed-up on this 1-core machine");ax.legend();ax.grid(axis="y",alpha=.3)
fig.tight_layout();fig.savefig("q3_speedup.png",dpi=200)
fig,ax=plt.subplots(figsize=(4.80,2.55));vals=[4000000,1000000,4000000,4000000]
ax.bar(["Expected","Unprotected","Mutex","Atomic"],vals,color=[ "gray",O,B,G]);ax.set_ylabel("Final counter value");ax.set_title("Q3: 4 threads x 1,000,000 increments");ax.grid(axis="y",alpha=.3)
for i,v in enumerate(vals):ax.text(i,v+6e4,f"{v:,}",ha="center",fontsize=7.4)
fig.tight_layout();fig.savefig("q3_race.png",dpi=200)
# Q4
b=rd("../Task04/output_bench.txt");mb=[r[0]+" MB" for r in b]
fig,ax=plt.subplots(figsize=(4.80,2.78));x=range(3);w=.38
ax.bar([i-w/2 for i in x],[float(r[1])*1000 for r in b],w,label="Pipe (2 copies)",color=B)
ax.bar([i+w/2 for i in x],[float(r[2])*1000 for r in b],w,label="Shared memory + semaphore",color=O)
ax.set_xticks(list(x));ax.set_xticklabels(mb);ax.set_ylabel("Transfer time (ms)");ax.set_title("Q4: Time to transfer data");ax.legend();ax.grid(axis="y",alpha=.3)
fig.tight_layout();fig.savefig("q4_transfer.png",dpi=200)
fig,ax=plt.subplots(figsize=(4.80,2.62))
ax.plot([1,10,100],[float(r[3])/1000 for r in b],"o-",label="Pipe",color=B);ax.plot([1,10,100],[float(r[4])/1000 for r in b],"s--",label="Shared memory + semaphore",color=O)
ax.set_xscale("log");ax.set_xlabel("Data size (MB, log scale)");ax.set_ylabel("Throughput (GB/s)");ax.set_title("Q4: Throughput by data size");ax.grid(alpha=.3,which="both");ax.legend()
fig.tight_layout();fig.savefig("q4_throughput.png",dpi=200)
# Q5
l=rd("../Task05/output_locks.txt")
fig,ax=plt.subplots(figsize=(4.80,2.70))
ax.bar([r[0] for r in l],[float(r[2]) for r in l],color=[B,O,G]);ax.set_ylabel("Bookings per second");ax.set_title("Q5: Throughput by lock granularity (16 agents)");ax.grid(axis="y",alpha=.3)
for i,r in enumerate(l):ax.text(i,float(r[2])+2000,f"{float(r[2]):,.0f}",ha="center",fontsize=7.4)
fig.tight_layout();fig.savefig("q5_locks.png",dpi=200)
a=rd("../Task05/output_atomic.txt");fig,ax=plt.subplots(figsize=(4.80,2.70))
for name,c,m in (("atomic",G,"o"),("mutex",B,"s"),("spinlock",O,"^")):
    pts=[(int(r[1]),float(r[2])) for r in a if r[0]==name];ax.plot(*zip(*pts),marker=m,color=c,label=name)
ax.set_xscale("log",base=2);ax.set_yscale("log");ax.set_xticks([1,4,16]);ax.set_xticklabels(["1","4","16"]);ax.set_xlabel("Threads");ax.set_ylabel("ns per update (log)");ax.set_title("Q5: Cost of one counter update");ax.legend();ax.grid(alpha=.3,which="both")
fig.tight_layout();fig.savefig("q5_atomic.png",dpi=200)
# Q6 timing
t=rd("../Task06/output_time.txt")
ns=[float(r[0]) for r in t[:3]];tm=[float(r[2]) for r in t[:3]]
fig,ax=plt.subplots(figsize=(4.80,2.70))
ax.loglog(ns,tm,"o-",color=B,label="Measured (m=5)");ref=[tm[0]*(n/ns[0])**2 for n in ns];ax.loglog(ns,ref,"--",color=O,label="Predicted O(n²) scaled from n=10")
ax.set_xlabel("Processes n");ax.set_ylabel("Time per safety check (ms)");ax.set_title("Q6: Safety algorithm running time");ax.legend();ax.grid(alpha=.3,which="both")
fig.tight_layout();fig.savefig("q6_time_n.png",dpi=200)
mm=[float(r[1]) for r in t[3:]];tm2=[float(r[2]) for r in t[3:]]
fig,ax=plt.subplots(figsize=(4.80,2.55));ax.plot(mm,tm2,"o-",color=G);ax.set_xlabel("Resource types m (n=200)");ax.set_ylabel("Time (ms)");ax.set_title("Q6: Growth with m (roughly linear, small slope)");ax.grid(alpha=.3);ax.set_ylim(0,max(tm2)*1.3)
fig.tight_layout();fig.savefig("q6_time_m.png",dpi=200)
# State diagram
fig,ax=plt.subplots(figsize=(5.25,2.92));ax.set_xlim(0,10);ax.set_ylim(0,6);ax.axis("off")
pos={"New":(1,3),"Ready":(4,4.6),"Running":(7.2,4.6),"Waiting":(5.6,1.2),"Terminated":(9,2.6)}
for k,(x,y) in pos.items():
    ax.add_patch(FancyBboxPatch((x-.85,y-.38),1.7,.76,boxstyle="round,pad=0.05",fc="#dbe8f5",ec=B,lw=1.5));ax.text(x,y,k,ha="center",va="center",fontsize=9.0,weight="bold")
def arr(a,b,txt,off=(0,0),rad=0.0,dx=(0,0)):
    (x1,y1),(x2,y2)=pos[a],pos[b]
    ax.add_patch(FancyArrowPatch((x1+dx[0],y1),(x2+dx[1],y2),arrowstyle="-|>",mutation_scale=14,connectionstyle=f"arc3,rad={rad}",color="black"))
    ax.text((x1+x2)/2+off[0],(y1+y2)/2+off[1],txt,fontsize=7.0,ha="center",va="center",bbox=dict(fc="white",ec="none",pad=1))
arr("New","Ready","admitted",(-.2,.4),0.0,(0.5,-0.5));arr("Ready","Running","scheduler dispatch",(0,.35),0.15)
arr("Running","Ready","interrupt (quantum over)",(0,-.45),0.15)
arr("Running","Waiting","I/O or event wait",(1.2,0),0.0,(-0.2,0.5));arr("Waiting","Ready","I/O or event done",(-1.6,-.2),0.0,(-0.3,0.3))
arr("Running","Terminated","exit",(.6,.2),0.0,(0.3,-0.3))
ax.set_title("Process state diagram",fontsize=9.8);fig.tight_layout();fig.savefig("q1_states.png",dpi=200)
# RAG deadlock
fig,ax=plt.subplots(figsize=(4.65,2.70));ax.set_xlim(0,10);ax.set_ylim(0,6);ax.axis("off")
P={"Job J1":(2,4.6),"Job J2":(8,4.6)};Rr={"GPU":(2,1.2),"Licence":(8,1.2)}
for k,(x,y) in P.items():ax.add_patch(Circle((x,y),.7,fc="#dbe8f5",ec=B,lw=1.5));ax.text(x,y,k,ha="center",va="center",fontsize=8.2)
for k,(x,y) in Rr.items():ax.add_patch(plt.Rectangle((x-.8,y-.45),1.6,.9,fc="#fbe5d6",ec=O,lw=1.5));ax.text(x,y,k,ha="center",va="center",fontsize=8.2)
def a(p1,p2,t,rad=0):ax.add_patch(FancyArrowPatch(p1,p2,arrowstyle="-|>",mutation_scale=14,connectionstyle=f"arc3,rad={rad}",color="black"));ax.text((p1[0]+p2[0])/2,(p1[1]+p2[1])/2,t,fontsize=7.0,bbox=dict(fc="white",ec="none",pad=1),ha="center")
a((2,1.7),(2,3.9),"assigned to",0);a((8,1.7),(8,3.9),"assigned to",0)
a((2.7,4.5),(7.3,1.5),"requests",0.0);a((7.3,4.7),(2.7,1.3),"requests",0.0)
# fix: J1 holds GPU (arrow resource->process), J1 requests Licence ; J2 holds Licence, requests GPU
ax.set_title("Resource-allocation graph: circular wait",fontsize=9.8);fig.tight_layout();fig.savefig("q6_rag.png",dpi=200)
print("done")
