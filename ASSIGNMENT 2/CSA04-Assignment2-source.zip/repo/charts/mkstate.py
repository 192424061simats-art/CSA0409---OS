import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch
plt.rcParams.update({"font.family":"serif","font.serif":["Liberation Serif"],"font.size":9})
B="#1f4e79"
fig,ax=plt.subplots(figsize=(5.40,2.92));ax.set_xlim(0,11.3);ax.set_ylim(0.4,6);ax.axis("off")
pos={"New":(1.2,3.2),"Ready":(4.2,4.8),"Running":(8,4.8),"Waiting":(6.1,1.2),"Terminated":(10,2.6)}
for k,(x,y) in pos.items():
    w=0.95 if k!="Terminated" else 1.0
    ax.add_patch(FancyBboxPatch((x-w,y-.38),2*w,.76,boxstyle="round,pad=0.04",fc="#dbe8f5",ec=B,lw=1.5));ax.text(x,y,k,ha="center",va="center",fontsize=9.0,weight="bold")
def A(p,q,txt,tp,rad=0):
    ax.annotate("",xy=q,xytext=p,arrowprops=dict(arrowstyle="-|>",lw=1.3,color="black",connectionstyle=f"arc3,rad={rad}"))
    ax.text(*tp,txt,fontsize=7.0,ha="center",va="center",bbox=dict(fc="white",ec="none",pad=1.2))
A((2.0,3.55),(3.4,4.5),"admitted",(2.1,4.35))
A((5.2,5.05),(7.0,5.05),"scheduler dispatch",(6.1,5.5))
A((7.0,4.55),(5.2,4.55),"interrupt / quantum over",(6.1,4.1))
A((7.6,4.4),(6.7,1.6),"I/O or event wait",(7.75,3.0))
A((5.3,1.55),(4.3,4.4),"I/O or event done",(4.2,2.6))
A((8.9,4.45),(9.7,3.0),"exit",(9.7,3.95))
ax.set_title("Process state diagram",fontsize=9.8);fig.tight_layout();fig.savefig("q1_states.png",dpi=200)
