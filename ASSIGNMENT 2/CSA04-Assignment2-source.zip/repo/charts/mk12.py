import json, matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
plt.rcParams.update({"font.family":"serif","font.serif":["Liberation Serif"],"font.size":9})
# Q1
import csv
rows=[l.strip().split(",") for l in open("../Task01/output_bench.txt") if l[0].isdigit()]
n=[int(r[0]) for r in rows];f=[float(r[1]) for r in rows];t=[float(r[2]) for r in rows]
fig,ax=plt.subplots(figsize=(4.65,2.70))
ax.plot(n,f,"o-",label="fork() + waitpid()",color="#1f4e79");ax.plot(n,t,"s--",label="pthread_create() + join",color="#c55a11")
ax.set_xlabel("Number of sessions created");ax.set_ylabel("Total time (ms)");ax.set_title("Q1: Creation cost, process vs thread");ax.grid(alpha=.3);ax.legend()
fig.tight_layout();fig.savefig("q1_create.png",dpi=200)
# Q1 memory model
fig,ax=plt.subplots(figsize=(4.65,2.70))
ns=[100,500,1000,2000]
proc=[x*(0.9+0.25) for x in ns]  # MB: ~0.9MB RSS measured + ~0.25 MB kernel/page tables (estimate)
thr=[x*0.0085 for x in ns]       # 8 KB stack touched ~ (estimate 8.5 KB)
ax.plot(ns,[p for p in proc],"o-",label="Process per session (~1.15 MB)",color="#1f4e79")
ax.plot(ns,thr,"s--",label="Thread per session (~8.5 KB)",color="#c55a11")
ax.set_yscale("log");ax.set_xlabel("Active sessions");ax.set_ylabel("Memory (MB, log scale)");ax.set_title("Q1: Memory footprint model");ax.grid(alpha=.3,which="both");ax.legend()
fig.tight_layout();fig.savefig("q1_memory.png",dpi=200)
# Q2
d=json.load(open("../Task02/sched.json"));res=d["res"];q=d["quanta"]
algs=["FCFS","SJF","SRTF","Priority","RR q=3","MLFQ 2/4/8"]
fig,ax=plt.subplots(figsize=(4.95,2.85));x=range(len(algs));w=.27
ax.bar([i-w for i in x],[res[a]["awt"] for a in algs],w,label="Avg waiting",color="#1f4e79")
ax.bar(x,[res[a]["atat"] for a in algs],w,label="Avg turnaround",color="#c55a11")
ax.bar([i+w for i in x],[res[a]["art"] for a in algs],w,label="Avg response",color="#548235")
ax.set_xticks(list(x));ax.set_xticklabels(algs,rotation=20);ax.set_ylabel("Time units");ax.set_title("Q2: Scheduling algorithms compared");ax.legend();ax.grid(axis="y",alpha=.3)
fig.tight_layout();fig.savefig("q2_algos.png",dpi=200)
fig,ax1=plt.subplots(figsize=(4.65,2.70));qq=["1","3","5","20"]
ax1.plot(qq,[q[k]["awt"] for k in qq],"o-",color="#1f4e79",label="Avg waiting time");ax1.set_xlabel("Time quantum");ax1.set_ylabel("Avg waiting time")
ax2=ax1.twinx();ax2.bar(qq,[q[k]["cs"] for k in qq],alpha=.3,color="#c55a11",label="Context switches");ax2.set_ylabel("Dispatches")
ax1.set_title("Q2: Effect of quantum on Round Robin");ax1.grid(alpha=.3)
h1,l1=ax1.get_legend_handles_labels();h2,l2=ax2.get_legend_handles_labels();ax1.legend(h1+h2,l1+l2,loc="upper right")
fig.tight_layout();fig.savefig("q2_quantum.png",dpi=200)
# Gantt for RR q=3 and SRTF
fig,axs=plt.subplots(2,1,figsize=(4.95,2.70),sharex=True)
cols={"P1":"#1f4e79","P2":"#c55a11","P3":"#548235","P4":"#7f6000"}
for ax,a in zip(axs,["RR q=3","SRTF"]):
    for n_,s,e in res[a]["gantt"]:
        ax.barh(0,e-s,left=s,color=cols[n_],edgecolor="white");ax.text((s+e)/2,0,n_,ha="center",va="center",color="white",fontsize=6.6)
    ax.set_yticks([]);ax.set_ylabel(a,rotation=0,ha="right",va="center")
axs[1].set_xlabel("Time");axs[0].set_title("Q2: Gantt charts");fig.tight_layout();fig.savefig("q2_gantt.png",dpi=200)
print("ok")
